<?php
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        require_once "conexion.php";
        $nombres = $_POST["nombres"];
        $apellidos = $_POST["apellidos"];
        $carrera = $_POST["carrera"];
        $years = $_POST["years"];


        $my_querry  = "Insert into Estudiante(nombres, apellidos, carrera, years) Values('$nombres', '$apellidos', '$carrera', $years);";
        $result = $conn->query($my_querry);
        if($result){
            echo "guardado exitosamente";
        }else{
            echo "Pain...";
        }
        $conn->close();
    }
?>