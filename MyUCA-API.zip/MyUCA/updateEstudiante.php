<?php
    if($_SERVER["REQUEST_METHOD"] == "PUT"){
        require_once "conexion.php";
        /* file_get_contents obtiene en "raw request". json_decode lo convierte a arreglo/objeto */
        $array= json_decode(file_get_contents("php://input"));

        $id = $array[0];
        $nombres = $array[1];
        $apellidos = $array[2];
        $carrera = $array[3];
        $years = $array[4];

        $my_query = "update Estudiante set nombres = '$nombres', apellidos = '$apellidos', carrera = '$carrera', years = $years where id = $id";
        $result = $conn->query($my_query);
        if($result){
            echo "guardado exitosamente";
        }else{
            echo "Pain";
        }
    }
?>