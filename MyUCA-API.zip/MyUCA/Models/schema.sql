use BDUCA;
create table Estudiante(
	id int UNIQUE not null AUTO_INCREMENT,
    nombres varchar(45),
    apellidos varchar(45),
    carrera varchar(45),
    years int,
    PRIMARY KEY (id)
)