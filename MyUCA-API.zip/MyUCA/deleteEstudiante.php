<?php
    if($_SERVER["REQUEST_METHOD"] == "DELETE"){
        require_once "conexion.php";
        $array = json_decode(file_get_contents("php://input"));

        $id = $array[0];

        $my_query = "delete from Estudiante where id = $id";
        $result = $conn->query($my_query);
        if($result){
            echo "eliminado exitosamente";
        }else{
            echo "Pain...";
        }
    }
?>