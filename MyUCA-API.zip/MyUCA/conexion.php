<?php
    $conn = mysqli_connect("localhost", "root","", "BDUCA", "3306");
    if(!$conn){
        echo "Error de conexion";
    }
?>